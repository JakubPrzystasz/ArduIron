var searchData=
[
  ['debouncer_33',['Debouncer',['../class_debouncer.html#a34c46ca04d4178933cc0049436d10fe6',1,'Debouncer']]],
  ['duration_34',['duration',['../class_debouncer.html#a462994f1f9a20876b2ee239eeee97448',1,'Debouncer']]]
];
